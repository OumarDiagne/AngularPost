import { Component, OnInit, Input } from '@angular/core';
import { getLocaleDateFormat } from '@angular/common';


@Component({
  selector: 'app-post-list-item',
  templateUrl: './post-list-item.component.html',
  styleUrls: ['./post-list-item.component.scss']
})
export class PostListItemComponent implements OnInit {
@Input() titrePost:string;
@Input() contentPost:string;
@Input() dateCreationPost:Date;
@Input() LoveIts:number;



  constructor() {
    this.dateCreationPost=new Date();
    this.LoveIts=0
   }

  ngOnInit() {
  
  }
  getOneMoreLove(){
 this.LoveIts++;
  }

  getOneLessLove(){
    this.LoveIts--;
  }
  getColorBackground(){
        if(this.LoveIts>0)
        return 'green';
        else return 'red';
  }
  
  
}
