import { Component, Input } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'post-project';
  date=new Date();
loveits=0;

  posts = [
    {  
      titre: 'premier post',
      contenu: 'Chez HLI , on bosse, mais on s amuse egalement ',
      loveIts:this.loveits,
      dateCreation:this.date
    },
    {
      titre: 'second post',
      contenu: ' Mohamed E alias mohamed ExceptionNullReference il est gentil , mais il devrait mettre sur slack plus souvent',
      loveIts:this.loveits,
      dateCreation:this.date
    },
    {
      titre: 'un autre post',
      contenu: 'la CAN cette année c est pété ! Yevgeny Kafelnikov meilleur joueur de tennis de tout les temps  ',
      loveIts:this.loveits,
      dateCreation:this.date
    },
    {
      titre: 'dernier post',
      contenu: 'Bomberman sur mega drive , meilleur jeu de tous les temps! ',
      loveIts:this.loveits,
      dateCreation:this.date
    },
    {
      titre: 'la der des der de post',
      contenu: 'Macron est le dirigeant qu il nous fallait ',
      loveIts:this.loveits,
      dateCreation:this.date
    }
  ];

  constructor() {}
}
